import os
import zipfile

def build_zip():
    repo_root = r"c:\Users\navee\OneDrive\Desktop\hackerrank-orchestrate-october26-main"
    zip_path = os.path.join(repo_root, "code.zip")
    
    # Files to include with their relative arcnames
    files_to_pack = [
        ("README.md", "README.md"),
        ("code/main.py", "code/main.py"),
        ("code/evaluation/evaluation_report.md", "code/evaluation/evaluation_report.md"),
        ("code/evaluation/usage_report.md", "code/evaluation/usage_report.md"),
        ("code/evaluation/evaluation_report.md", "evaluation/evaluation_report.md"),
        ("code/evaluation/usage_report.md", "evaluation/usage_report.md"),
    ]
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for rel_src, arcname in files_to_pack:
            abs_src = os.path.join(repo_root, rel_src.replace('/', os.sep))
            if os.path.exists(abs_src):
                print(f"Adding {rel_src} -> {arcname}")
                zf.write(abs_src, arcname)
            else:
                print(f"ERROR: {abs_src} does not exist!")

    print(f"\nCreated {zip_path} successfully.")
    with zipfile.ZipFile(zip_path, 'r') as zf:
        print("\nZip contents:")
        for info in zf.infolist():
            print(f"  {info.filename} ({info.file_size} bytes)")

if __name__ == "__main__":
    build_zip()
