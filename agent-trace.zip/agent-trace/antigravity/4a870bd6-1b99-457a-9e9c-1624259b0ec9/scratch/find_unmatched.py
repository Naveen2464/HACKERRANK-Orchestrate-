import os, json, sqlite3, pypdf, re, glob
import pandas as pd

eval_req = pd.read_csv('dataset/deletion_requests.csv')
evidence_files = pd.read_csv('dataset/evidence_files.csv')
users_df = pd.read_csv('dataset/user_identities.csv')
audit_df = pd.read_csv('dataset/user_audit_log.csv')

users_df['email_lower'] = users_df['email'].str.lower()
audit_df['old_lower'] = audit_df['old_value'].str.lower()
audit_df['new_lower'] = audit_df['new_value'].str.lower()

def resolve_user(email):
    e = email.lower()
    u = users_df[users_df['email_lower'] == e]
    if len(u) > 0: return u.iloc[0]['user_id']
    a = audit_df[(audit_df['old_lower'] == e) | (audit_df['new_lower'] == e)]
    if len(a) > 0: return a.iloc[0]['user_id']
    return None

def get_user_identifiers(uid):
    u = users_df[users_df['user_id'] == uid]
    emails = set()
    if len(u) > 0:
        row = u.iloc[0]
        if pd.notna(row['email']): emails.add(str(row['email']).lower())
    a = audit_df[audit_df['user_id'] == uid]
    for idx, row in a.iterrows():
        for val in [row['old_value'], row['new_value']]:
            if pd.notna(val) and row['field_name'] == 'email':
                emails.add(str(val).lower())
    return uid, emails

evidence_data = []
for idx, r in evidence_files.iterrows():
    fpath = os.path.join('dataset', r['file_path'])
    fid = r['file_id']
    cap_at = r['captured_at']
    text = ""
    if os.path.exists(fpath):
        if fpath.endswith('.pdf'):
            try:
                reader = pypdf.PdfReader(fpath)
                text = " ".join([p.extract_text() for p in reader.pages])
            except:
                pass
        else:
            try:
                with open(fpath, 'r', encoding='utf-8', errors='ignore') as fp:
                    text = fp.read()
            except:
                pass
    evidence_data.append({
        'file_id': fid,
        'captured_at': cap_at,
        'path': r['file_path'],
        'text': text,
        'text_lower': text.lower()
    })

unmatched = []
for idx, r in eval_req.iterrows():
    cid = r['case_id']
    uid = resolve_user(r['email'])
    uid, emails = get_user_identifiers(uid)
    audit_at = r['audit_at']
    matched = []
    for ef in evidence_data:
        if ef['captured_at'] <= audit_at:
            if uid in ef['text'] or any(e in ef['text_lower'] for e in emails):
                matched.append(ef['file_id'])
    if not matched:
        unmatched.append((cid, uid, r['email'], r['audit_at'], r['request_text']))

print(f"Total unmatched: {len(unmatched)}")
for u in unmatched:
    print(u)
