import json, pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
users_df = pd.read_csv('dataset/user_identities.csv')
audit_df = pd.read_csv('dataset/user_audit_log.csv')

users_df['email_lower'] = users_df['email'].str.lower()
audit_df['old_lower'] = audit_df['old_value'].str.lower()
audit_df['new_lower'] = audit_df['new_value'].str.lower()

def resolve_user(email):
    e = email.lower()
    u = users_df[users_df['email_lower'] == e]
    if len(u) > 0: return u.iloc[0]['user_id']
    a = audit_df[(audit_df['old_lower'] == e) | (audit_df['new_lower'] == e)]
    if len(a) > 0: return a.iloc[0]['user_id']
    return None

for idx, r in sample_out.iterrows():
    cid = r['case_id']
    req = sample_req[sample_req['case_id'] == cid].iloc[0]
    uid = resolve_user(req['email'])
    steps = json.loads(r['steps_json'])
    print(f"{cid} ({r.deletion_status}) uid={uid}: {[(s['operation'], s['resource_id'], s['evidence_id']) for s in steps]}")
