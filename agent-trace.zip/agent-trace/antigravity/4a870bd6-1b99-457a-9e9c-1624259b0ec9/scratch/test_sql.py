import glob, sqlite3, os

sql_files = glob.glob('dataset/evidence/databases/*.sql')
print(f'Total SQL files: {len(sql_files)}')
errors = []
for f in sql_files:
    conn = sqlite3.connect(':memory:')
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            sql_text = fp.read()
        conn.executescript(sql_text)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        total_rows = 0
        for t in tables:
            cursor.execute(f"SELECT COUNT(*) FROM {t}")
            total_rows += cursor.fetchone()[0]
        # print(f'{os.path.basename(f)}: tables={len(tables)}, rows={total_rows}')
    except Exception as e:
        errors.append((os.path.basename(f), str(e)))
    finally:
        conn.close()

print(f'SQL Execution errors: {len(errors)}')
if errors:
    print('Errors:', errors)
else:
    print('All 24 SQL files executed in SQLite successfully!')
