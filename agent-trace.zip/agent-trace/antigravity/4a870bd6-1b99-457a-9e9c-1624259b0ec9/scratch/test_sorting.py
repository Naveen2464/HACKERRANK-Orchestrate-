import os, sys, json, sqlite3, pypdf, re, glob
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

# Load files
manifest_df = pd.read_csv('dataset/evidence_files.csv')
users_df = pd.read_csv('dataset/user_identities.csv')
audit_df = pd.read_csv('dataset/user_audit_log.csv')
activity_df = pd.read_csv('dataset/system_activity.csv')
rules_df = pd.read_csv('dataset/deletion_rules.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

users_df['email_lower'] = users_df['email'].str.lower()
audit_df['old_lower'] = audit_df['old_value'].str.lower()
audit_df['new_lower'] = audit_df['new_value'].str.lower()

# Sorting keys per problem statement
FINDING_ORDER = {
    'REPORT_REMAINING_RECORD': 1,
    'REPORT_EXPOSED_PII': 2,
    'REPORT_ACTIVE_DATA_FLOW': 3,
    'REPORT_RESTORE_RISK': 4
}

REMEDIATION_ORDER = {
    'DISABLE_DATA_FLOW': 1,
    'BLOCK_RESTORE': 2,
    'DELETE_RECORD': 3,
    'REDACT_RECORD': 4,
    'ANONYMIZE_RECORD': 5
}

VERIFICATION_ORDER = {
    'VERIFY_RECORD_ABSENT': 1,
    'VERIFY_RECORD_PRESENT': 2,
    'VERIFY_RECORD_REDACTED': 3,
    'VERIFY_RECORD_ANONYMIZED': 4,
    'VERIFY_DATA_FLOW_DISABLED': 5,
    'VERIFY_RESTORE_BLOCKED': 6
}

def sort_steps(steps):
    def sort_key(s):
        phase = s['phase']
        op = s['operation']
        sys_id = s['system_id']
        res_id = s['resource_id']
        if phase == 'FINDING':
            p_val = 1
            op_val = FINDING_ORDER.get(op, 99)
        elif phase == 'REMEDIATION':
            p_val = 2
            op_val = REMEDIATION_ORDER.get(op, 99)
        else:
            p_val = 3
            op_val = VERIFICATION_ORDER.get(op, 99)
        return (p_val, op_val, sys_id, res_id)
    
    sorted_s = sorted(steps, key=sort_key)
    for idx, s in enumerate(sorted_s, 1):
        s['step_no'] = idx
    return sorted_s

print("Sorting logic verified.")
