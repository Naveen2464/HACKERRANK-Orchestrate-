import os, json, sqlite3, pypdf, re, glob
import pandas as pd

# Load manifest and core dataset
evidence_files = pd.read_csv('dataset/evidence_files.csv')
users_df = pd.read_csv('dataset/user_identities.csv')
audit_df = pd.read_csv('dataset/user_audit_log.csv')
activity_df = pd.read_csv('dataset/system_activity.csv')
rules_df = pd.read_csv('dataset/deletion_rules.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

users_df['email_lower'] = users_df['email'].str.lower()
audit_df['old_lower'] = audit_df['old_value'].str.lower()
audit_df['new_lower'] = audit_df['new_value'].str.lower()

def resolve_user(email):
    e = email.lower()
    u = users_df[users_df['email_lower'] == e]
    if len(u) > 0:
        return u.iloc[0]['user_id']
    a = audit_df[(audit_df['old_lower'] == e) | (audit_df['new_lower'] == e)]
    if len(a) > 0:
        return a.iloc[0]['user_id']
    return None

def get_all_identifiers(uid):
    u = users_df[users_df['user_id'] == uid]
    emails = set()
    names = set()
    phones = set()
    hashes = set()
    if len(u) > 0:
        row = u.iloc[0]
        if pd.notna(row['email']): emails.add(str(row['email']).lower())
        if pd.notna(row['name']): names.add(str(row['name']).lower())
        if pd.notna(row['phone']): phones.add(str(row['phone']))
        if pd.notna(row['email_hash']): hashes.add(str(row['email_hash']).lower())
    
    a = audit_df[audit_df['user_id'] == uid]
    for idx, row in a.iterrows():
        field = row['field_name']
        for val in [row['old_value'], row['new_value']]:
            if pd.notna(val):
                sval = str(val).lower()
                if field == 'email': emails.add(sval)
                elif field == 'name': names.add(sval)
                elif field == 'phone': phones.add(str(val))
                elif field == 'email_hash': hashes.add(sval)
    return {
        'user_id': uid,
        'emails': emails,
        'names': names,
        'phones': phones,
        'hashes': hashes
    }

print("Extractor framework initialized.")
