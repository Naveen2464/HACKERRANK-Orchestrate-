import pandas as pd, json

df = pd.read_csv('dataset/system_activity.csv')
acc_records = df[(df['target_system'] == 'account_service') & (df['event_type'] == 'DELETE_RECORD')].copy()
requests = pd.read_csv('dataset/sample_deletion_requests.csv')
samples = pd.read_csv('dataset/sample_output.csv')

# Parse timestamps
acc_records['event_dt'] = pd.to_datetime(acc_records['event_time'])

sample_accs = {}
for idx, r in samples.iterrows():
    steps = json.loads(r['steps_json'])
    for s in steps:
        if s['system_id'] == 'account_service':
            sample_accs[r['case_id']] = s['resource_id']

matched = 0
for idx, req in requests.iterrows():
    cid = req['case_id']
    target_acc = sample_accs.get(cid)
    req_dt = pd.to_datetime(req['requested_at'])
    rep_dt = pd.to_datetime(req['reported_at'])
    
    # Check activity events between requested_at - 1 hour and reported_at + 1 hour
    candidates = acc_records[(acc_records['event_dt'] >= req_dt - pd.Timedelta(hours=2)) & 
                             (acc_records['event_dt'] <= rep_dt + pd.Timedelta(hours=2))]
    cand_res = candidates['resource_id'].tolist()
    is_match = target_acc in cand_res
    if is_match:
        matched += 1
    else:
        print(f"Mismatch for {cid}: target={target_acc}, req={req.requested_at}, rep={req.reported_at}, cand={cand_res}")

print(f"Matched {matched} / {len(requests)} sample cases to account_service via time window!")
