import glob, os

logs = glob.glob('dataset/evidence/logs/*.log')
for f in sorted(logs):
    with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
        first_few = [fp.readline().strip() for _ in range(3)]
        print(f"=== {os.path.basename(f)} ===")
        for line in first_few:
            if line:
                print("  ", line[:120])
