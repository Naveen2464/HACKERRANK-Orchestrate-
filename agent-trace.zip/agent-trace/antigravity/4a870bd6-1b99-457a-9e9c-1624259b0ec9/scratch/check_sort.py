import json, pandas as pd

sample_out = pd.read_csv('dataset/sample_output.csv')

FINDING_ORDER = {
    'REPORT_REMAINING_RECORD': 1,
    'REPORT_EXPOSED_PII': 2,
    'REPORT_ACTIVE_DATA_FLOW': 3,
    'REPORT_RESTORE_RISK': 4
}

REMEDIATION_ORDER = {
    'DISABLE_DATA_FLOW': 1,
    'BLOCK_RESTORE': 2,
    'DELETE_RECORD': 3,
    'REDACT_RECORD': 4,
    'ANONYMIZE_RECORD': 5
}

VERIFICATION_ORDER = {
    'VERIFY_RECORD_ABSENT': 1,
    'VERIFY_RECORD_PRESENT': 2,
    'VERIFY_RECORD_REDACTED': 3,
    'VERIFY_RECORD_ANONYMIZED': 4,
    'VERIFY_DATA_FLOW_DISABLED': 5,
    'VERIFY_RESTORE_BLOCKED': 6
}

def sort_key(s):
    phase = s['phase']
    op = s['operation']
    sys_id = s['system_id']
    res_id = s['resource_id']
    if phase == 'FINDING':
        p_val = 1
        op_val = FINDING_ORDER.get(op, 99)
    elif phase == 'REMEDIATION':
        p_val = 2
        op_val = REMEDIATION_ORDER.get(op, 99)
    else:
        p_val = 3
        op_val = VERIFICATION_ORDER.get(op, 99)
    return (p_val, op_val, sys_id, res_id)

mismatches = 0
for idx, r in sample_out.iterrows():
    steps = json.loads(r['steps_json'])
    sorted_steps = sorted(steps, key=sort_key)
    for orig, s in zip(steps, sorted_steps):
        if (orig['phase'], orig['operation'], orig['system_id'], orig['resource_id']) != (s['phase'], s['operation'], s['system_id'], s['resource_id']):
            print(f"Sort mismatch in {r.case_id}: orig={orig['operation']}:{orig['resource_id']} vs sorted={s['operation']}:{s['resource_id']}")
            mismatches += 1

print(f"Total sort mismatches: {mismatches}")
