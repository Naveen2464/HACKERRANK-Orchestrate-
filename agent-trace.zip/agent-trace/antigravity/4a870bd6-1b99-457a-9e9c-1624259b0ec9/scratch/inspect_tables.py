import glob, sqlite3, os

sql_files = glob.glob('dataset/evidence/databases/*.sql')
schema_info = {}
for f in sql_files:
    conn = sqlite3.connect(':memory:')
    with open(f, 'r', encoding='utf-8') as fp:
        conn.executescript(fp.read())
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [row[0] for row in cursor.fetchall()]
    for t in tables:
        cursor.execute(f"PRAGMA table_info({t});")
        cols = [col[1] for col in cursor.fetchall()]
        schema_info[t] = cols
    conn.close()

for t, cols in sorted(schema_info.items()):
    print(f'{t}: {cols}')
