import os, sys, json, sqlite3, pypdf, re, glob
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

# Load files
manifest_df = pd.read_csv('dataset/evidence_files.csv')
users_df = pd.read_csv('dataset/user_identities.csv')
audit_df = pd.read_csv('dataset/user_audit_log.csv')
activity_df = pd.read_csv('dataset/system_activity.csv')
rules_df = pd.read_csv('dataset/deletion_rules.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

users_df['email_lower'] = users_df['email'].str.lower()
audit_df['old_lower'] = audit_df['old_value'].str.lower()
audit_df['new_lower'] = audit_df['new_value'].str.lower()

# Map file_path -> (file_id, captured_at, origin)
evidence_manifest = {}
for idx, r in manifest_df.iterrows():
    evidence_manifest[r['file_path']] = {
        'file_id': r['file_id'],
        'captured_at': r['captured_at'],
        'origin': r['origin']
    }

# Identity resolution helper
def get_user_id(email):
    e = email.lower()
    u = users_df[users_df['email_lower'] == e]
    if len(u) > 0:
        return u.iloc[0]['user_id']
    a = audit_df[(audit_df['old_lower'] == e) | (audit_df['new_lower'] == e)]
    if len(a) > 0:
        return a.iloc[0]['user_id']
    return None

def get_user_identifiers(uid):
    u = users_df[users_df['user_id'] == uid]
    emails = set()
    names = set()
    phones = set()
    hashes = set()
    if len(u) > 0:
        row = u.iloc[0]
        if pd.notna(row['email']): emails.add(str(row['email']).lower())
        if pd.notna(row['name']): names.add(str(row['name']).lower())
        if pd.notna(row['phone']): phones.add(str(row['phone']))
        if pd.notna(row['email_hash']): hashes.add(str(row['email_hash']).lower())
    
    a = audit_df[audit_df['user_id'] == uid]
    for idx, row in a.iterrows():
        field = row['field_name']
        for val in [row['old_value'], row['new_value']]:
            if pd.notna(val):
                sval = str(val).lower()
                if field == 'email': emails.add(sval)
                elif field == 'name': names.add(sval)
                elif field == 'phone': phones.add(str(val))
                elif field == 'email_hash': hashes.add(sval)
    return {
        'user_id': uid,
        'emails': emails,
        'names': names,
        'phones': phones,
        'hashes': hashes
    }

# Request authorization helper
def is_deletion_request(text):
    t = text.lower()
    # Explicit non-deletion requests
    non_del_patterns = [
        r'leave the account active',
        r'not asking for deletion',
        r'keep the account as it is',
        r'do not close the account',
        r'without removing any of my records',
        r'marketing lists only',
        r'not a request to erase',
        r'leave my profile',
        r'continue using the service',
        r"don't delete or change anything",
        r'do not delete',
        r'keep my account',
        r'keep the profile'
    ]
    for p in non_del_patterns:
        if re.search(p, t):
            return False
    return True

print("Helper functions ready.")
