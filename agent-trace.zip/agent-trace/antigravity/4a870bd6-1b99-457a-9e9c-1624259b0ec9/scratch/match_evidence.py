import os, json, sqlite3, pypdf, re, glob
import pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
evidence_files = pd.read_csv('dataset/evidence_files.csv')
users_df = pd.read_csv('dataset/user_identities.csv')
audit_df = pd.read_csv('dataset/user_audit_log.csv')

users_df['email_lower'] = users_df['email'].str.lower()
audit_df['old_lower'] = audit_df['old_value'].str.lower()
audit_df['new_lower'] = audit_df['new_value'].str.lower()

def resolve_user(email):
    e = email.lower()
    u = users_df[users_df['email_lower'] == e]
    if len(u) > 0: return u.iloc[0]['user_id']
    a = audit_df[(audit_df['old_lower'] == e) | (audit_df['new_lower'] == e)]
    if len(a) > 0: return a.iloc[0]['user_id']
    return None

def get_user_identifiers(uid):
    u = users_df[users_df['user_id'] == uid]
    emails = set()
    if len(u) > 0:
        row = u.iloc[0]
        if pd.notna(row['email']): emails.add(str(row['email']).lower())
    a = audit_df[audit_df['user_id'] == uid]
    for idx, row in a.iterrows():
        for val in [row['old_value'], row['new_value']]:
            if pd.notna(val) and row['field_name'] == 'email':
                emails.add(str(val).lower())
    return uid, emails

for idx, r in sample_out.iterrows():
    cid = r['case_id']
    req = sample_req[sample_req['case_id'] == cid].iloc[0]
    audit_at = req['audit_at']
    uid, emails = get_user_identifiers(resolve_user(req['email']))
    steps = json.loads(r['steps_json'])
    expected_evs = list(dict.fromkeys([s['evidence_id'] for s in steps if s['evidence_id']]))
    
    # Check which evidence files captured at or before audit_at contain uid or any email
    matching_efs = []
    for _, ef in evidence_files.iterrows():
        cap_at = ef['captured_at']
        if cap_at <= audit_at:
            fpath = os.path.join('dataset', ef['file_path'])
            if os.path.exists(fpath):
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as fp:
                        content = fp.read()
                        # check if uid or email is in content
                        has_id = (uid in content) or any(e in content.lower() for e in emails)
                        if has_id:
                            matching_efs.append((ef['file_id'], cap_at, ef['origin']))
                except:
                    pass
    print(f"{cid} (audit={audit_at}) expected: {expected_evs}")
    print(f"   matched files: {[m[0] for m in matching_efs]}")
