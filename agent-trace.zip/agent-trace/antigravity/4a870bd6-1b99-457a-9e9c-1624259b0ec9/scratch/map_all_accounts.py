import os, re, glob
import pandas as pd

email_to_acc = {}

# 1. Search in handover txt
for p in glob.glob('dataset/evidence/records/*.txt'):
    with open(p, 'r', encoding='utf-8') as fp:
        for line in fp:
            m = re.search(r'account_service\s*\|\s*(account_\d+)\s*\|\s*USER_PROFILE\s*\|\s*NOT_FOUND\s*\|\s*([^\s\|]+)', line)
            if m:
                email_to_acc[m.group(2).strip().lower()] = m.group(1).strip()

# 2. Search in resource lookup trace logs
for p in glob.glob('dataset/evidence/logs/resource_lookup_trace_*.log'):
    with open(p, 'r', encoding='utf-8') as fp:
        for line in fp:
            m = re.search(r'service=account_service.*resource_id=(account_\d+).*lookup_key=([^\s]+)', line)
            if m:
                email_to_acc[m.group(2).strip().lower()] = m.group(1).strip()

# 3. Search in service_events logs
for p in glob.glob('dataset/evidence/logs/*service_events*.log'):
    with open(p, 'r', encoding='utf-8') as fp:
        cur_acc = None
        for line in fp:
            m_res = re.search(r'resource_id=(account_\d+)', line)
            if m_res: cur_acc = m_res.group(1)
            m_key = re.search(r'lookup_key="([^"]+)"', line)
            if m_key and cur_acc:
                email_to_acc[m_key.group(1).strip().lower()] = cur_acc

# 4. Search in SQL files
for p in glob.glob('dataset/evidence/databases/*.sql'):
    with open(p, 'r', encoding='utf-8') as fp:
        for line in fp:
            m = re.search(r"'(account_\d+)','(user_\d+)',[^,]+,'([^']+)'", line)
            if m:
                email_to_acc[m.group(3).strip().lower()] = m.group(1).strip()

# 5. Search in JSON snapshot bundles
for p in glob.glob('dataset/evidence/records/*.json'):
    try:
        with open(p, 'r', encoding='utf-8') as fp:
            c = fp.read()
            for m in re.finditer(r'"resource_id"\s*:\s*"(account_\d+)".*?"email"\s*:\s*"([^"]+)"', c):
                email_to_acc[m.group(2).strip().lower()] = m.group(1).strip()
    except:
        pass

print(f"Total direct email -> account mappings found: {len(email_to_acc)}")
for em, acc in list(email_to_acc.items())[:15]:
    print(em, "->", acc)
