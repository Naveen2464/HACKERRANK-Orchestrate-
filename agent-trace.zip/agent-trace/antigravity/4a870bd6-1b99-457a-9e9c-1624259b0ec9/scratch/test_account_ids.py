import pandas as pd, json, re, glob, os

users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')
requests = pd.read_csv('dataset/deletion_requests.csv')
sample_requests = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

users['email_lower'] = users['email'].str.lower()
audit['old_lower'] = audit['old_value'].str.lower()
audit['new_lower'] = audit['new_value'].str.lower()

def resolve_user(email):
    e = email.lower()
    u = users[users['email_lower'] == e]
    if len(u) > 0:
        return u.iloc[0]['user_id']
    a = audit[(audit['old_lower'] == e) | (audit['new_lower'] == e)]
    if len(a) > 0:
        return a.iloc[0]['user_id']
    return None

# Check sample accounts
sample_actual_accs = {}
for idx, r in sample_out.iterrows():
    steps = json.loads(r['steps_json'])
    for s in steps:
        if s['system_id'] == 'account_service':
            sample_actual_accs[r['case_id']] = s['resource_id']

print(f"Sample cases with account_service: {len(sample_actual_accs)} / {len(sample_out)}")
for cid, acc in list(sample_actual_accs.items())[:10]:
    print(cid, acc)
