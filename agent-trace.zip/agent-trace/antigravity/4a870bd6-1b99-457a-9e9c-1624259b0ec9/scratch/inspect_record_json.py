import glob, sqlite3, json

sql_files = glob.glob('dataset/evidence/databases/*.sql')
for f in sql_files:
    conn = sqlite3.connect(':memory:')
    with open(f, 'r', encoding='utf-8') as fp:
        conn.executescript(fp.read())
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [row[0] for row in cursor.fetchall()]
    for t in tables:
        if 'customer_data' in t and t not in ['customer_data_inventory']:
            cursor.execute(f"PRAGMA table_info({t});")
            cols = [col[1] for col in cursor.fetchall()]
            if 'record_json' in cols:
                cursor.execute(f"SELECT origin_system, collection_name, record_json FROM {t} LIMIT 3;")
                rows = cursor.fetchall()
                if rows:
                    print(f'=== {t} in {f} ===')
                    for r in rows:
                        print(r[0], r[1], r[2][:120])
    conn.close()
