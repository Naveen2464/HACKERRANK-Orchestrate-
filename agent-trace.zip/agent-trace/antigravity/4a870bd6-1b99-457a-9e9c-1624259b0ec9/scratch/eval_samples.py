import pandas as pd, json

pred = pd.read_csv('sample_predictions.csv')
gold = pd.read_csv('dataset/sample_output.csv')

total = len(gold)
status_correct = 0
steps_exact_matches = 0

print("=== SAMPLE EVALUATION RESULTS ===")
for idx in range(total):
    p_row = pred.iloc[idx]
    g_row = gold.iloc[idx]
    cid = g_row['case_id']
    
    status_match = p_row['deletion_status'] == g_row['deletion_status']
    if status_match:
        status_correct += 1
    
    p_steps = json.loads(p_row['steps_json'])
    g_steps = json.loads(g_row['steps_json'])
    
    p_keys = [(s['phase'], s['operation'], s['system_id'], s['resource_id'], s['state']) for s in p_steps]
    g_keys = [(s['phase'], s['operation'], s['system_id'], s['resource_id'], s['state']) for s in g_steps]
    
    steps_match = (p_keys == g_keys)
    if steps_match:
        steps_exact_matches += 1
    else:
        print(f"\n{cid} MISMATCH:")
        print(f"  Status: Pred={p_row.deletion_status}, Gold={g_row.deletion_status}")
        print(f"  Gold steps ({len(g_steps)}):")
        for s in g_steps:
            print(f"    [{s['phase']}] {s['operation']} -> {s['system_id']}:{s['resource_id']} (ev: {s['evidence_id']})")
        print(f"  Pred steps ({len(p_steps)}):")
        for s in p_steps:
            print(f"    [{s['phase']}] {s['operation']} -> {s['system_id']}:{s['resource_id']} (ev: {s['evidence_id']})")

print(f"\nStatus Accuracy: {status_correct}/{total} ({status_correct/total*100:.2f}%)")
print(f"Exact Steps Match: {steps_exact_matches}/{total} ({steps_exact_matches/total*100:.2f}%)")
