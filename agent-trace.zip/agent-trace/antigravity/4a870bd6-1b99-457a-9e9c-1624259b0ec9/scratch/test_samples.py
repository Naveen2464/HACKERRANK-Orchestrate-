import json, os, sqlite3, pypdf, re, glob
import pandas as pd

# Load manifest and core dataset
evidence_files = pd.read_csv('dataset/evidence_files.csv')
users_df = pd.read_csv('dataset/user_identities.csv')
audit_df = pd.read_csv('dataset/user_audit_log.csv')
activity_df = pd.read_csv('dataset/system_activity.csv')
rules_df = pd.read_csv('dataset/deletion_rules.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

print(f"Loaded {len(sample_req)} sample requests and {len(sample_out)} sample outputs.")
