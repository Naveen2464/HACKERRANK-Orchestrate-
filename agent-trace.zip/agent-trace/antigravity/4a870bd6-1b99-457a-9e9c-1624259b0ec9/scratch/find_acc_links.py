import os, json, sqlite3, pypdf, re, glob
import pandas as pd

# Find where account_4857 and account_8858 are mentioned in ANY file in dataset
for root, dirs, files in os.walk('dataset'):
    for f in files:
        p = os.path.join(root, f)
        try:
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                c = fp.read()
                if 'account_4857' in c:
                    print(f"account_4857 in {p}")
                if 'account_8858' in c:
                    print(f"account_8858 in {p}")
        except:
            pass
