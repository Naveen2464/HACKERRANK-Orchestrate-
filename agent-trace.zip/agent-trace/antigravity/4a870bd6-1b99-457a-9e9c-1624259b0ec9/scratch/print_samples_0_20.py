import pandas as pd, json

samples = pd.read_csv('dataset/sample_output.csv')
requests = pd.read_csv('dataset/sample_deletion_requests.csv')

for idx, r in samples.iloc[0:20].iterrows():
    cid = r['case_id']
    req = requests[requests['case_id'] == cid].iloc[0]
    steps = json.loads(r['steps_json'])
    print(f"=== {cid} ({r.deletion_status}) | req: {req.requested_at} | rep: {req.reported_status} | audit: {req.audit_at} ===")
    for s in steps:
        print(f"  step {s['step_no']}: [{s['phase']}] {s['operation']} -> {s['system_id']}:{s['resource_id']} (state: {s['state']}, ev: '{s['evidence_id']}')")
