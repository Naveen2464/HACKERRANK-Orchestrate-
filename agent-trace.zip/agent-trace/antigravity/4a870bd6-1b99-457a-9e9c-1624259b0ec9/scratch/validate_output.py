import os, sys, json
import pandas as pd

df = pd.read_csv('output.csv')
print(f"Total rows in output.csv: {len(df)}")
print(f"Columns: {list(df.columns)}")

expected_cols = ['case_id', 'deletion_status', 'steps_json']
assert list(df.columns) == expected_cols, f"Columns mismatch: {list(df.columns)} vs {expected_cols}"
assert len(df) == 518, f"Row count mismatch: {len(df)} vs 518"

# Check sorting
case_ids = df['case_id'].tolist()
assert case_ids == sorted(case_ids), "output.csv is not sorted by case_id"

valid_statuses = {'COMPLETE', 'INCOMPLETE', 'NOT_APPLICABLE'}
status_counts = df['deletion_status'].value_counts()
print(f"Status distribution:\n{status_counts}")

for idx, r in df.iterrows():
    cid = r['case_id']
    st = r['deletion_status']
    assert st in valid_statuses, f"Invalid status: {st} in {cid}"
    
    steps = json.loads(r['steps_json'])
    assert isinstance(steps, list), f"steps_json is not list in {cid}"
    
    if st == 'NOT_APPLICABLE':
        assert len(steps) == 0, f"NOT_APPLICABLE must have empty steps in {cid}"
    else:
        for i, s in enumerate(steps, 1):
            assert s['step_no'] == i, f"Step numbering error in {cid}: {s['step_no']} != {i}"
            assert s['phase'] in {'FINDING', 'REMEDIATION', 'VERIFICATION'}, f"Invalid phase: {s['phase']} in {cid}"
            assert 'system_id' in s and 'resource_id' in s and 'operation' in s and 'state' in s and 'evidence_id' in s
            
            if s['phase'] == 'FINDING':
                assert s['evidence_id'] != "", f"Finding must cite evidence_id in {cid}"
            elif s['phase'] == 'REMEDIATION':
                assert s['evidence_id'] == "", f"Remediation must have empty evidence_id in {cid}"
            elif s['phase'] == 'VERIFICATION':
                if st == 'COMPLETE':
                    assert s['evidence_id'] != "", f"COMPLETE verification must cite evidence_id in {cid}"
                elif st == 'INCOMPLETE':
                    assert s['evidence_id'] == "", f"INCOMPLETE future verification must have empty evidence_id in {cid}"

print("All 518 rows in output.csv PASSED validation flawlessly!")
