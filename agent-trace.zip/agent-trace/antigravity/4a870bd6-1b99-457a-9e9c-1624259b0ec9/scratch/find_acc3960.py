import os

targets = ['account_3960', 'k.appiah88@gmail.com']
for root, dirs, files in os.walk('dataset'):
    for f in files:
        p = os.path.join(root, f)
        try:
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                c = fp.read()
                for t in targets:
                    if t in c:
                        print(f"Found {t} in {p}")
        except:
            pass
