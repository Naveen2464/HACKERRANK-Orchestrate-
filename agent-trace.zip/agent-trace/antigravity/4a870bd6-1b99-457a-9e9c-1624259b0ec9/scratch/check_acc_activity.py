import pandas as pd

df = pd.read_csv('dataset/system_activity.csv')
acc_records = df[(df['target_system'] == 'account_service') & (df['event_type'] == 'DELETE_RECORD')]
print(f"Total DELETE_RECORD on account_service in system_activity: {len(acc_records)}")
print(acc_records[['activity_id', 'event_time', 'resource_id', 'reported_result', 'details']].head(10))
