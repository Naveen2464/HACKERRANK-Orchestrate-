import os, sys, json, sqlite3, pypdf, re, glob
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

# 1. Load ground truth
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

print(f"Sample requests: {len(sample_req)}, Sample outputs: {len(sample_out)}")
