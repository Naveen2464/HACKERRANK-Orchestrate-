import os, sys, json, sqlite3, pypdf, re, glob
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

# 1. Load manifest and core dataset
manifest_df = pd.read_csv('dataset/evidence_files.csv')
users_df = pd.read_csv('dataset/user_identities.csv')
audit_df = pd.read_csv('dataset/user_audit_log.csv')
activity_df = pd.read_csv('dataset/system_activity.csv')
rules_df = pd.read_csv('dataset/deletion_rules.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

users_df['email_lower'] = users_df['email'].str.lower()
audit_df['old_lower'] = audit_df['old_value'].str.lower()
audit_df['new_lower'] = audit_df['new_value'].str.lower()

# Map file_path -> file_id and captured_at
evidence_map = {}
for idx, r in manifest_df.iterrows():
    evidence_map[r['file_path']] = (r['file_id'], r['captured_at'], r['origin'])

print(f"Evidence files mapped: {len(evidence_map)}")
